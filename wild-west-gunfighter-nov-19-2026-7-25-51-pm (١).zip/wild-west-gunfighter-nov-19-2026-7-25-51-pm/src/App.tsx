/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useCallback, useEffect, useRef, useState } from 'react';
import { ArmoryModal } from './components/ArmoryModal';
import { GameHud } from './components/GameHud';
import { LegendsModal } from './components/LegendsModal';
import { ModalOverlays } from './components/ModalOverlays';
import { TitleScreen } from './components/TitleScreen';
import { TradingShopModal } from './components/TradingShopModal';
import {
  ANIMAL_SPECIES,
  DEFAULT_HUNTING_BAG,
  getHuntingBagCount,
  getHuntingBagTotalValue,
} from './game/animals';
import { WesternAudioEngine } from './game/audio';
import { WestGameEngine } from './game/engine';
import {
  DEFAULT_LEGENDS_RECORD,
  mergeStageResultIntoLegends,
} from './game/legends';
import { STAGES } from './game/stages';
import {
  AnimalSpeciesId,
  Difficulty,
  GameScreenState,
  HudSnapshot,
  HuntingBag,
  LegendsRecord,
  PlayerLoadout,
  StageId,
  StageStats,
} from './game/types';
import {
  DEFAULT_LOADOUT,
  DYNAMITE_COST,
  MAX_DYNAMITE,
  MAX_TONICS,
  TONIC_COST,
  UpgradeKey,
} from './game/upgrades';

const SAVE_KEY = 'west_bullets_save_v1';

interface SavedProgress {
  bounty: number;
  loadout: PlayerLoadout;
  huntingBag: HuntingBag;
  legendsRecord: LegendsRecord;
  posseEnabled: boolean;
}

function loadSavedProgress(): SavedProgress {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) {
      return {
        bounty: 250,
        loadout: { ...DEFAULT_LOADOUT },
        huntingBag: { ...DEFAULT_HUNTING_BAG },
        legendsRecord: { ...DEFAULT_LEGENDS_RECORD },
        posseEnabled: true,
      };
    }
    const parsed = JSON.parse(raw) as Partial<SavedProgress>;
    return {
      bounty: typeof parsed.bounty === 'number' ? parsed.bounty : 250,
      loadout: { ...DEFAULT_LOADOUT, ...(parsed.loadout ?? {}) },
      huntingBag: { ...DEFAULT_HUNTING_BAG, ...(parsed.huntingBag ?? {}) },
      legendsRecord: {
        ...DEFAULT_LEGENDS_RECORD,
        ...(parsed.legendsRecord ?? {}),
      },
      posseEnabled:
        typeof parsed.posseEnabled === 'boolean' ? parsed.posseEnabled : true,
    };
  } catch {
    return {
      bounty: 250,
      loadout: { ...DEFAULT_LOADOUT },
      huntingBag: { ...DEFAULT_HUNTING_BAG },
      legendsRecord: { ...DEFAULT_LEGENDS_RECORD },
      posseEnabled: true,
    };
  }
}

export default function App() {
  const initialSave = useRef<SavedProgress>(loadSavedProgress());

  const [screen, setScreen] = useState<GameScreenState>('TITLE');
  const [selectedStage, setSelectedStage] = useState<StageId>('ghost_town');
  const [difficulty, setDifficulty] = useState<Difficulty>('normal');
  const [bounty, setBounty] = useState<number>(initialSave.current.bounty);
  const [loadout, setLoadout] = useState<PlayerLoadout>(
    initialSave.current.loadout
  );
  const [huntingBag, setHuntingBag] = useState<HuntingBag>(
    initialSave.current.huntingBag
  );
  const [legendsRecord, setLegendsRecord] = useState<LegendsRecord>(
    initialSave.current.legendsRecord
  );
  const [posseEnabled, setPosseEnabled] = useState<boolean>(
    initialSave.current.posseEnabled
  );
  const [armoryOpen, setArmoryOpen] = useState(false);
  const [shopOpen, setShopOpen] = useState(false);
  const [legendsOpen, setLegendsOpen] = useState(false);
  const [muted, setMuted] = useState(false);
  const [showTouchControls, setShowTouchControls] = useState<boolean>(() => {
    if (typeof window !== 'undefined' && window.matchMedia) {
      return window.matchMedia('(pointer: coarse)').matches;
    }
    return false;
  });
  const [hud, setHud] = useState<HudSnapshot | null>(null);
  const [lastStats, setLastStats] = useState<StageStats | null>(null);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const audioRef = useRef<WesternAudioEngine | null>(null);
  const engineRef = useRef<WestGameEngine | null>(null);

  const screenRef = useRef(screen);
  screenRef.current = screen;
  const loadoutRef = useRef(loadout);
  loadoutRef.current = loadout;
  const bountyRef = useRef(bounty);
  bountyRef.current = bounty;
  const huntingBagRef = useRef(huntingBag);
  huntingBagRef.current = huntingBag;
  const posseEnabledRef = useRef(posseEnabled);
  posseEnabledRef.current = posseEnabled;

  useEffect(() => {
    try {
      localStorage.setItem(
        SAVE_KEY,
        JSON.stringify({
          bounty,
          loadout,
          huntingBag,
          legendsRecord,
          posseEnabled,
        })
      );
    } catch {
      // Ignore storage quota errors
    }
  }, [bounty, loadout, huntingBag, legendsRecord, posseEnabled]);

  useEffect(() => {
    const audio = new WesternAudioEngine();
    audioRef.current = audio;
    const canvas = canvasRef.current;
    if (!canvas) return;

    const engine = new WestGameEngine(canvas, audio, {
      onHudUpdate: (snapshot) => {
        setHud(snapshot);
      },
      onStageClear: (stageId, stats) => {
        setBounty(stats.bountyEarned);
        setLastStats(stats);
        setLegendsRecord((prev) =>
          mergeStageResultIntoLegends(prev, stageId, true, stats)
        );
        if (stageId === 'boss_duel') {
          setScreen('VICTORY');
        } else {
          setScreen('STAGE_CLEAR');
        }
      },
      onGameOver: (stageId, stats) => {
        setBounty(stats.bountyEarned);
        setLastStats(stats);
        setLegendsRecord((prev) =>
          mergeStageResultIntoLegends(prev, stageId, false, stats)
        );
        setScreen('GAME_OVER');
      },
      onPauseRequested: () => {
        setScreen((prev) => {
          if (prev === 'PLAYING') {
            engine.setPaused(true);
            return 'PAUSED';
          }
          if (prev === 'PAUSED') {
            engine.setPaused(false);
            return 'PLAYING';
          }
          return prev;
        });
      },
      onTonicUsed: (remaining) => {
        setLoadout((prev) => ({ ...prev, tonicsCount: remaining }));
      },
      onDynamiteUsed: (remaining) => {
        setLoadout((prev) => ({ ...prev, dynamiteCount: remaining }));
      },
      onAnimalHunted: (species) => {
        setHuntingBag((prev) => ({
          ...prev,
          [species]: (prev[species] || 0) + 1,
        }));
        const tier = ANIMAL_SPECIES[species].tier;
        setLegendsRecord((prev) => ({
          ...prev,
          totalAnimalsHunted: prev.totalAnimalsHunted + 1,
          rareAnimalsHunted:
            prev.rareAnimalsHunted +
            (tier === 'hard' || tier === 'legendary' ? 1 : 0),
          legendaryAnimalsHunted:
            prev.legendaryAnimalsHunted + (tier === 'legendary' ? 1 : 0),
        }));
      },
    });
    engineRef.current = engine;

    return () => {
      engine.destroy();
      engineRef.current = null;
    };
  }, []);

  const handleToggleMute = useCallback(() => {
    setMuted((prev) => {
      const next = !prev;
      audioRef.current?.setMuted(next);
      return next;
    });
  }, []);

  const launchStage = useCallback(
    (stageId: StageId) => {
      audioRef.current?.unlock();
      setSelectedStage(stageId);
      setLastStats(null);
      setScreen('PLAYING');
      engineRef.current?.startStage(
        stageId,
        difficulty,
        bountyRef.current,
        loadoutRef.current,
        posseEnabledRef.current
      );
    },
    [difficulty]
  );

  const handleStartFromTitle = useCallback(() => {
    launchStage(selectedStage);
  }, [launchStage, selectedStage]);

  const handleResume = useCallback(() => {
    engineRef.current?.setPaused(false);
    setScreen('PLAYING');
  }, []);

  const handlePauseFromHud = useCallback(() => {
    if (screenRef.current === 'PLAYING') {
      engineRef.current?.setPaused(true);
      setScreen('PAUSED');
    }
  }, []);

  const handleRestartStage = useCallback(() => {
    launchStage(selectedStage);
  }, [launchStage, selectedStage]);

  const handleNextStage = useCallback(() => {
    const idx = STAGES.findIndex((s) => s.id === selectedStage);
    const next = STAGES[idx + 1] ?? STAGES[0];
    launchStage(next.id);
  }, [launchStage, selectedStage]);

  const handleReturnTitle = useCallback(() => {
    engineRef.current?.stop();
    setScreen('TITLE');
  }, []);

  const handleUpgrade = useCallback((key: UpgradeKey, cost: number) => {
    if (bountyRef.current < cost || loadoutRef.current[key] >= 3) return;
    setBounty((prev) => Math.max(0, prev - cost));
    setLoadout((prev) => ({
      ...prev,
      [key]: Math.min(3, prev[key] + 1),
    }));
    audioRef.current?.playReloadComplete(true);
  }, []);

  const handleBuyTonic = useCallback(() => {
    if (
      bountyRef.current < TONIC_COST ||
      loadoutRef.current.tonicsCount >= MAX_TONICS
    ) {
      return;
    }
    setBounty((prev) => Math.max(0, prev - TONIC_COST));
    setLoadout((prev) => ({
      ...prev,
      tonicsCount: Math.min(MAX_TONICS, prev.tonicsCount + 1),
    }));
    audioRef.current?.playPickup();
  }, []);

  const handleBuyDynamite = useCallback(() => {
    if (
      bountyRef.current < DYNAMITE_COST ||
      loadoutRef.current.dynamiteCount >= MAX_DYNAMITE
    ) {
      return;
    }
    setBounty((prev) => Math.max(0, prev - DYNAMITE_COST));
    setLoadout((prev) => ({
      ...prev,
      dynamiteCount: Math.min(MAX_DYNAMITE, prev.dynamiteCount + 1),
    }));
    audioRef.current?.playPickup();
  }, []);

  const handleSellOne = useCallback((species: AnimalSpeciesId) => {
    const owned = huntingBagRef.current[species] || 0;
    if (owned <= 0) return;
    const price = ANIMAL_SPECIES[species].sellPrice;
    setHuntingBag((prev) => ({
      ...prev,
      [species]: Math.max(0, (prev[species] || 0) - 1),
    }));
    setBounty((prev) => prev + price);
    audioRef.current?.playPickup();
  }, []);

  const handleSellSpeciesAll = useCallback((species: AnimalSpeciesId) => {
    const owned = huntingBagRef.current[species] || 0;
    if (owned <= 0) return;
    const total = owned * ANIMAL_SPECIES[species].sellPrice;
    setHuntingBag((prev) => ({
      ...prev,
      [species]: 0,
    }));
    setBounty((prev) => prev + total);
    audioRef.current?.playPickup();
  }, []);

  const handleSellEverything = useCallback(() => {
    const total = getHuntingBagTotalValue(huntingBagRef.current);
    if (total <= 0) return;
    setHuntingBag({ ...DEFAULT_HUNTING_BAG });
    setBounty((prev) => prev + total);
    audioRef.current?.playReloadComplete(true);
  }, []);

  const huntingBagCount = getHuntingBagCount(huntingBag);
  const huntingBagValue = getHuntingBagTotalValue(huntingBag);

  return (
    <main className="relative w-screen h-screen overflow-hidden bg-[#120A06]">
      {/* Isolated Canvas Layer */}
      <canvas
        ref={canvasRef}
        className={`block w-full h-full ${
          screen === 'PLAYING' && !showTouchControls
            ? 'cursor-none'
            : 'cursor-crosshair'
        }`}
      />

      {/* Title Screen */}
      {screen === 'TITLE' && (
        <div className="fixed inset-0 z-30">
          <TitleScreen
            selectedStage={selectedStage}
            onSelectStage={setSelectedStage}
            difficulty={difficulty}
            onSelectDifficulty={setDifficulty}
            bounty={bounty}
            huntingBagCount={huntingBagCount}
            loadout={loadout}
            legendsRecord={legendsRecord}
            posseEnabled={posseEnabled}
            onTogglePosse={() => setPosseEnabled((v) => !v)}
            muted={muted}
            onToggleMute={handleToggleMute}
            onOpenArmory={() => setArmoryOpen(true)}
            onOpenShop={() => setShopOpen(true)}
            onOpenLegends={() => setLegendsOpen(true)}
            onStartGame={handleStartFromTitle}
          />
        </div>
      )}

      {/* Active Play HUD */}
      {screen === 'PLAYING' && hud && (
        <GameHud
          hud={hud}
          muted={muted}
          showTouchControls={showTouchControls}
          onToggleTouchControls={() => setShowTouchControls((v) => !v)}
          onToggleMute={handleToggleMute}
          onPause={handlePauseFromHud}
          onUseTonic={() => engineRef.current?.tryUseTonic()}
          onThrowDynamite={() => engineRef.current?.tryThrowDynamite()}
          onToggleWalk={() => engineRef.current?.toggleWalkMode()}
          onSelectWeapon={(w) => engineRef.current?.selectWeapon(w)}
          onCycleWeapon={(dir) => engineRef.current?.cycleWeapon(dir)}
          onVirtualMove={(dx, dy) => engineRef.current?.setVirtualMove(dx, dy)}
          onVirtualFire={(firing) => engineRef.current?.setVirtualFire(firing)}
          onReload={() => engineRef.current?.triggerReload()}
          onDodge={() => engineRef.current?.triggerDodge()}
          onDeadeye={() => engineRef.current?.triggerDeadeye()}
          onToggleScope={() => engineRef.current?.toggleScope()}
          onZoomScope={(delta) => engineRef.current?.zoomScope(delta)}
          onTogglePosseHold={() => engineRef.current?.togglePosseHold()}
        />
      )}

      {/* Pause / Stage Clear / Game Over / Victory Modals */}
      {screen !== 'TITLE' && screen !== 'PLAYING' && (
        <ModalOverlays
          screen={screen}
          stageId={selectedStage}
          stats={lastStats}
          totalBounty={bounty}
          huntingBagCount={huntingBagCount}
          huntingBagValue={huntingBagValue}
          onResume={handleResume}
          onRestartStage={handleRestartStage}
          onNextStage={handleNextStage}
          onOpenArmory={() => setArmoryOpen(true)}
          onOpenShop={() => setShopOpen(true)}
          onReturnTitle={handleReturnTitle}
        />
      )}

      {/* Gunsmith & Armory Upgrade Workshop Modal */}
      {armoryOpen && (
        <ArmoryModal
          bounty={bounty}
          loadout={loadout}
          onUpgrade={handleUpgrade}
          onBuyTonic={handleBuyTonic}
          onBuyDynamite={handleBuyDynamite}
          onClose={() => setArmoryOpen(false)}
        />
      )}

      {/* Hunter's Trading Shop Modal */}
      {shopOpen && (
        <TradingShopModal
          bounty={bounty}
          huntingBag={huntingBag}
          onSellOne={handleSellOne}
          onSellSpeciesAll={handleSellSpeciesAll}
          onSellEverything={handleSellEverything}
          onOpenArmory={() => {
            setShopOpen(false);
            setArmoryOpen(true);
          }}
          onClose={() => setShopOpen(false)}
        />
      )}

      {/* Hall of Legends Modal */}
      {legendsOpen && (
        <LegendsModal
          record={legendsRecord}
          onClose={() => setLegendsOpen(false)}
        />
      )}
    </main>
  );
}
