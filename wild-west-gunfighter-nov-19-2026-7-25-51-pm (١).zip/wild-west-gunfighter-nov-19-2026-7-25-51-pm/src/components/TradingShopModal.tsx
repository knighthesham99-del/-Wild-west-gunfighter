import React, { useState } from 'react';
import { Store, Coins, Wrench, X } from 'lucide-react';
import {
  ANIMAL_SPECIES,
  ANIMAL_SPECIES_LIST,
  getHuntingBagCount,
  getHuntingBagTotalValue,
} from '../game/animals';
import { AnimalSpeciesId, AnimalTier, HuntingBag } from '../game/types';

interface TradingShopModalProps {
  bounty: number;
  huntingBag: HuntingBag;
  onSellOne: (species: AnimalSpeciesId) => void;
  onSellSpeciesAll: (species: AnimalSpeciesId) => void;
  onSellEverything: () => void;
  onOpenArmory?: () => void;
  onClose: () => void;
}

type ShopFilter = 'all' | AnimalTier;

export const TradingShopModal: React.FC<TradingShopModalProps> = ({
  bounty,
  huntingBag,
  onSellOne,
  onSellSpeciesAll,
  onSellEverything,
  onOpenArmory,
  onClose,
}) => {
  const [filter, setFilter] = useState<ShopFilter>('all');

  const bagCount = getHuntingBagCount(huntingBag);
  const bagTotalValue = getHuntingBagTotalValue(huntingBag);

  const visibleSpecies =
    filter === 'all'
      ? ANIMAL_SPECIES_LIST
      : ANIMAL_SPECIES_LIST.filter((s) => s.tier === filter);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4"
      role="dialog"
      aria-modal="true"
      aria-label="متجر الصيد والتجارة"
    >
      <div className="w-full max-w-3xl bg-[#1A100B] border-2 border-[#0B0705] ring-1 ring-inset ring-[#D99B26]/30 rounded-lg shadow-[0_10px_0_#0B0705] overflow-hidden text-[#F3E5CE]">
        {/* Top bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#3A2315] bg-[#140B07]">
          <div className="flex items-center gap-3">
            <Store className="w-5 h-5 text-[#D99B26]" />
            <div>
              <h2 className="text-xl font-bold text-[#F3E5CE]">
                متجر الصيد وتجارة الفراء
              </h2>
              <p className="text-xs text-[#B89F80]">
                بِع غنائم الصيد من الطرائد السهلة وحتى الوحوش الأسطورية مقابل الدولارات الذهبية
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="text-left">
              <div className="text-[11px] text-[#B89F80]">الرصيد المتاح</div>
              <div className="text-xl font-bold text-[#FBBF24] font-mono-nums">
                ${bounty.toLocaleString()}
              </div>
            </div>
            <button
              onClick={onClose}
              aria-label="إغلاق المتجر"
              className="p-2 rounded-lg border border-[#4A2E1B] text-[#D4BE9E] hover:text-white hover:border-[#D99B26] transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tier Filter Tabs */}
        <div className="flex items-center justify-between gap-3 px-6 pt-3 border-b border-[#3A2315] overflow-x-auto">
          <div className="flex items-center gap-2">
            {(
              [
                { id: 'all', label: 'كل الطرائد' },
                { id: 'easy', label: 'سهل' },
                { id: 'medium', label: 'متوسط' },
                { id: 'hard', label: 'صعب' },
                { id: 'legendary', label: 'أسطوري' },
              ] as const
            ).map((t) => (
              <button
                key={t.id}
                onClick={() => setFilter(t.id)}
                className={`px-3.5 py-2.5 text-sm font-bold border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  filter === t.id
                    ? 'border-[#D99B26] text-[#FBBF24]'
                    : 'border-transparent text-[#A88F72] hover:text-[#F3E5CE]'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          <div className="text-xs text-[#D4BE9E] pb-2 whitespace-nowrap shrink-0">
            في الحقيبة:{' '}
            <span className="font-mono-nums font-bold text-[#34D399]">
              {bagCount}
            </span>{' '}
            قطعة
          </div>
        </div>

        {/* Animal Trophy Price List & Inventory */}
        <div className="p-6 max-h-[54vh] overflow-y-auto grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {visibleSpecies.map((spec) => {
            const owned = huntingBag[spec.id] || 0;
            const totalForSpec = owned * spec.sellPrice;

            return (
              <div
                key={spec.id}
                className="flex flex-col justify-between p-4 rounded-lg bg-[#140B07] border border-[#3A2315] gap-3"
              >
                <div className="space-y-1.5">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="font-bold text-base text-[#F3E5CE]">
                        {spec.lootNameAr}
                      </div>
                      <div className="text-xs text-[#B89F80] mt-0.5 flex items-center gap-2">
                        <span>المصدر: {spec.nameAr}</span>
                        <span aria-hidden="true">·</span>
                        <span
                          className="font-bold"
                          style={{ color: spec.tierColor }}
                        >
                          صعوبة {spec.tierLabelAr}
                        </span>
                      </div>
                    </div>

                    <div className="text-left shrink-0">
                      <div className="text-sm font-bold text-[#FBBF24] font-mono-nums">
                        ${spec.sellPrice}
                      </div>
                      <div className="text-[11px] text-[#9A8165]">للقطعة</div>
                    </div>
                  </div>

                  <p className="text-xs text-[#A88F72] leading-relaxed">
                    {spec.descAr}
                  </p>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-[#2C1A10] gap-2">
                  <div className="text-xs text-[#D4BE9E]">
                    المتاح لديك:{' '}
                    <span
                      className={`font-mono-nums font-bold text-sm ${
                        owned > 0 ? 'text-[#34D399]' : 'text-[#6B543F]'
                      }`}
                    >
                      {owned}
                    </span>
                    {owned > 0 && (
                      <span className="text-[11px] text-[#B89F80] mr-1.5 font-mono-nums">
                        (${totalForSpec.toLocaleString()})
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => onSellOne(spec.id)}
                      disabled={owned <= 0}
                      className="px-3 py-1.5 rounded bg-[#24160F] hover:bg-[#3A2315] border border-[#5A3A21] text-xs font-bold text-[#F3E5CE] disabled:opacity-35 disabled:cursor-not-allowed transition-colors cursor-pointer whitespace-nowrap"
                    >
                      بيع 1 (+${ANIMAL_SPECIES[spec.id].sellPrice})
                    </button>
                    {owned > 1 && (
                      <button
                        onClick={() => onSellSpeciesAll(spec.id)}
                        className="px-3 py-1.5 rounded bg-[#D99B26] hover:bg-[#FBBF24] text-xs font-extrabold text-[#140B07] transition-colors cursor-pointer whitespace-nowrap"
                      >
                        بيع الكل
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer Actions */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-6 py-4 border-t border-[#3A2315] bg-[#140B07]">
          <div className="flex items-center gap-2 text-xs sm:text-sm text-[#D4BE9E]">
            <span>قيمة الغنائم غير المباعة:</span>
            <span className="font-mono-nums font-bold text-base text-[#34D399]">
              ${bagTotalValue.toLocaleString()}
            </span>
          </div>

          <div className="flex items-center gap-2.5">
            {onOpenArmory && (
              <button
                onClick={onOpenArmory}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#24160F] hover:bg-[#3A2315] border border-[#5A3A21] text-xs font-bold text-[#F3E5CE] transition-colors cursor-pointer whitespace-nowrap"
              >
                <Wrench className="w-3.5 h-3.5 text-[#D99B26]" />
                <span>الذهاب للترسانة</span>
              </button>
            )}

            <button
              onClick={onSellEverything}
              disabled={bagCount <= 0}
              className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#D99B26] hover:bg-[#FBBF24] disabled:bg-[#2E1E12] disabled:text-[#785C42] text-[#140B07] font-extrabold text-sm transition-colors cursor-pointer disabled:cursor-not-allowed whitespace-nowrap"
            >
              <Coins className="w-4 h-4" />
              <span>
                {bagCount > 0
                  ? `بيع جميع الغنائم (+$${bagTotalValue.toLocaleString()})`
                  : 'الحقيبة فارغة — اصطد في سهول الصيد'}
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
