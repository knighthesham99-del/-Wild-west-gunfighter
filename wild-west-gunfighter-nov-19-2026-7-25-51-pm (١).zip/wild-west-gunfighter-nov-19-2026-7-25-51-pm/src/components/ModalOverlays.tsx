import React from 'react';
import { Store, Wrench } from 'lucide-react';
import { STAGES } from '../game/stages';
import { GameScreenState, StageId, StageStats } from '../game/types';

interface ModalOverlaysProps {
  screen: Exclude<GameScreenState, 'TITLE' | 'PLAYING'>;
  stageId: StageId;
  stats: StageStats | null;
  totalBounty: number;
  huntingBagCount: number;
  huntingBagValue: number;
  onResume: () => void;
  onRestartStage: () => void;
  onNextStage: () => void;
  onOpenArmory: () => void;
  onOpenShop: () => void;
  onReturnTitle: () => void;
}

export const ModalOverlays: React.FC<ModalOverlaysProps> = ({
  screen,
  stageId,
  stats,
  totalBounty,
  huntingBagCount,
  huntingBagValue,
  onResume,
  onRestartStage,
  onNextStage,
  onOpenArmory,
  onOpenShop,
  onReturnTitle,
}) => {
  const stageMeta = STAGES.find((s) => s.id === stageId) ?? STAGES[0];
  const accuracy =
    stats && stats.shotsFired > 0
      ? Math.round((stats.shotsHit / stats.shotsFired) * 100)
      : 0;

  return (
    <div
      className="fixed inset-0 z-40 flex items-center justify-center bg-black/75 p-4"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full max-w-md bg-[#1A100B] border-2 border-[#0B0705] ring-1 ring-inset ring-[#D99B26]/35 rounded-lg p-6 text-[#F3E5CE] shadow-[0_8px_0_#0B0705] space-y-5">
        {screen === 'PAUSED' && (
          <>
            <div className="space-y-1 text-center">
              <h2 className="text-2xl font-extrabold text-[#FBBF24]">
                إيقاف مؤقت
              </h2>
              <p className="text-xs text-[#B89F80]">{stageMeta.titleAr}</p>
            </div>
            <div className="flex flex-col gap-2.5">
              <button
                onClick={onResume}
                className="w-full py-3 rounded-lg bg-[#D99B26] hover:bg-[#FBBF24] text-[#140B07] font-bold text-sm transition-colors cursor-pointer"
              >
                متابعة القتال
              </button>
              <button
                onClick={onRestartStage}
                className="w-full py-2.5 rounded-lg bg-[#2A1910] hover:bg-[#3A2316] border border-[#4A2E1B] text-sm font-bold transition-colors cursor-pointer"
              >
                إعادة المرحلة
              </button>
              <button
                onClick={onReturnTitle}
                className="w-full py-2.5 rounded-lg bg-[#140B07] hover:bg-[#24160F] border border-[#3A2315] text-sm text-[#B89F80] transition-colors cursor-pointer"
              >
                القائمة الرئيسية
              </button>
            </div>
          </>
        )}

        {(screen === 'STAGE_CLEAR' || screen === 'VICTORY') && (
          <>
            <div className="space-y-1 text-center">
              <div className="text-xs font-bold text-[#34D399]">
                {screen === 'VICTORY'
                  ? 'أكملت جميع مراحل الغرب!'
                  : `المرحلة 0${stageMeta.order} مكتملة`}
              </div>
              <h2 className="text-2xl font-extrabold text-[#FBBF24]">
                {screen === 'VICTORY' ? 'أسطورة الغرب الأمريكي' : stageMeta.titleAr}
              </h2>
            </div>

            {stats && (
              <div className="grid grid-cols-2 gap-3 p-4 rounded-lg bg-[#140B07] border border-[#3A2315] text-sm">
                <div>
                  <div className="text-xs text-[#9A8165]">إجمالي الرصيد</div>
                  <div className="text-lg font-bold text-[#FBBF24] font-mono-nums">
                    ${totalBounty.toLocaleString()}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-[#9A8165]">الأعداء المهزومون</div>
                  <div className="text-lg font-bold font-mono-nums">
                    {stats.kills}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-[#9A8165]">دقة التصويب</div>
                  <div className="text-lg font-bold font-mono-nums">
                    {accuracy}%
                  </div>
                </div>
                <div>
                  <div className="text-xs text-[#9A8165]">أقصى تتابع</div>
                  <div className="text-lg font-bold font-mono-nums">
                    ×{stats.maxCombo}
                  </div>
                </div>
              </div>
            )}

            <div className="flex flex-col gap-2.5">
              {screen === 'STAGE_CLEAR' ? (
                <button
                  onClick={onNextStage}
                  className="w-full py-3 rounded-lg bg-[#D99B26] hover:bg-[#FBBF24] text-[#140B07] font-extrabold text-sm transition-colors cursor-pointer"
                >
                  الانتقال للمرحلة التالية
                </button>
              ) : (
                <button
                  onClick={onRestartStage}
                  className="w-full py-3 rounded-lg bg-[#D99B26] hover:bg-[#FBBF24] text-[#140B07] font-extrabold text-sm transition-colors cursor-pointer"
                >
                  لعب النزال مجدداً
                </button>
              )}

              <button
                onClick={onOpenArmory}
                className="w-full py-2.5 rounded-lg bg-[#2A1910] hover:bg-[#3A2316] border border-[#D99B26]/60 text-[#FBBF24] font-bold text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Wrench className="w-4 h-4" />
                <span>الترسانة وتطوير الأسلحة (${totalBounty.toLocaleString()})</span>
              </button>

              {(huntingBagCount > 0 || stageId === 'hunting_grounds') && (
                <button
                  onClick={onOpenShop}
                  className="w-full py-2.5 rounded-lg bg-[#1E2B1C] hover:bg-[#273A24] border border-[#34D399]/60 text-[#6EE7B7] font-bold text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <Store className="w-4 h-4" />
                  <span>
                    {huntingBagCount > 0
                      ? `متجر الصيد · بيع الغنائم (+$${huntingBagValue.toLocaleString()})`
                      : 'متجر الصيد وتجارة الفراء'}
                  </span>
                </button>
              )}

              <button
                onClick={onReturnTitle}
                className="w-full py-2.5 rounded-lg bg-[#140B07] hover:bg-[#24160F] border border-[#3A2315] text-sm text-[#B89F80] transition-colors cursor-pointer"
              >
                القائمة الرئيسية
              </button>
            </div>
          </>
        )}

        {screen === 'GAME_OVER' && (
          <>
            <div className="space-y-1 text-center">
              <div className="text-xs font-bold text-[#EF4444]">
                نهاية المواجهة
              </div>
              <h2 className="text-2xl font-extrabold text-[#F3E5CE]">
                سقطت في {stageMeta.titleAr}
              </h2>
            </div>

            {stats && (
              <div className="grid grid-cols-2 gap-3 p-4 rounded-lg bg-[#140B07] border border-[#3A2315] text-sm">
                <div>
                  <div className="text-xs text-[#9A8165]">الرصيد المحفوظ</div>
                  <div className="text-lg font-bold text-[#FBBF24] font-mono-nums">
                    ${totalBounty.toLocaleString()}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-[#9A8165]">الأعداء المهزومون</div>
                  <div className="text-lg font-bold font-mono-nums">
                    {stats.kills}
                  </div>
                </div>
              </div>
            )}

            <div className="flex flex-col gap-2.5">
              <button
                onClick={onRestartStage}
                className="w-full py-3 rounded-lg bg-[#DC2626] hover:bg-[#EF4444] text-white font-extrabold text-sm transition-colors cursor-pointer"
              >
                إعادة المحاولة
              </button>
              <button
                onClick={onOpenArmory}
                className="w-full py-2.5 rounded-lg bg-[#2A1910] hover:bg-[#3A2316] border border-[#D99B26]/60 text-[#FBBF24] font-bold text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Wrench className="w-4 h-4" />
                <span>تطوير الأسلحة والمعدات</span>
              </button>
              {(huntingBagCount > 0 || stageId === 'hunting_grounds') && (
                <button
                  onClick={onOpenShop}
                  className="w-full py-2.5 rounded-lg bg-[#1E2B1C] hover:bg-[#273A24] border border-[#34D399]/60 text-[#6EE7B7] font-bold text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <Store className="w-4 h-4" />
                  <span>
                    {huntingBagCount > 0
                      ? `متجر الصيد · بيع الغنائم (+$${huntingBagValue.toLocaleString()})`
                      : 'متجر الصيد وتجارة الفراء'}
                  </span>
                </button>
              )}
              <button
                onClick={onReturnTitle}
                className="w-full py-2.5 rounded-lg bg-[#140B07] hover:bg-[#24160F] border border-[#3A2315] text-sm text-[#B89F80] transition-colors cursor-pointer"
              >
                القائمة الرئيسية
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
