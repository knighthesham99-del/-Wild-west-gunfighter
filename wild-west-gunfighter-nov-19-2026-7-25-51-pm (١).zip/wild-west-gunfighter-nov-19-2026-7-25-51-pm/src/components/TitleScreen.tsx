import React, { useEffect } from 'react';
import { Volume2, VolumeX, Wrench, Heart, Store, Trophy, Users } from 'lucide-react';
import { LEGEND_ACHIEVEMENTS } from '../game/legends';
import { STAGES } from '../game/stages';
import { Difficulty, LegendsRecord, PlayerLoadout, StageId } from '../game/types';
import { computeEffectiveStats } from '../game/upgrades';

interface TitleScreenProps {
  selectedStage: StageId;
  onSelectStage: (stage: StageId) => void;
  difficulty: Difficulty;
  onSelectDifficulty: (d: Difficulty) => void;
  bounty: number;
  huntingBagCount: number;
  loadout: PlayerLoadout;
  legendsRecord: LegendsRecord;
  posseEnabled: boolean;
  onTogglePosse: () => void;
  muted: boolean;
  onToggleMute: () => void;
  onOpenArmory: () => void;
  onOpenShop: () => void;
  onOpenLegends: () => void;
  onStartGame: () => void;
}

const BACKDROP_URL =
  '/src/assets/images/dan_west_title_art_1795042480047.jpg';

export const TitleScreen: React.FC<TitleScreenProps> = ({
  selectedStage,
  onSelectStage,
  difficulty,
  onSelectDifficulty,
  bounty,
  huntingBagCount,
  loadout,
  legendsRecord,
  posseEnabled,
  onTogglePosse,
  muted,
  onToggleMute,
  onOpenArmory,
  onOpenShop,
  onOpenLegends,
  onStartGame,
}) => {
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.code === 'Enter' || e.code === 'Space') {
        if (
          document.activeElement &&
          document.activeElement.tagName === 'BUTTON'
        ) {
          return;
        }
        e.preventDefault();
        onStartGame();
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [onStartGame]);

  const currentStageMeta =
    STAGES.find((s) => s.id === selectedStage) ?? STAGES[0];
  const effective = computeEffectiveStats(loadout);
  const legendsUnlockedCount = LEGEND_ACHIEVEMENTS.filter(
    (a) => a.evaluate(legendsRecord).unlocked
  ).length;

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#120A06]">
      {/* Dan-the-Man Pixel-Art Key Illustration */}
      <img
        src={BACKDROP_URL}
        alt="بطل الغرب الأمريكي بأسلوب البكسل الكلاسيكي"
        referrerPolicy="no-referrer"
        className="absolute inset-0 w-full h-full object-cover object-left"
      />

      {/* Scrim on right side for RTL controls while keeping pixel-art cowboy hero & train bright on the left */}
      <div className="absolute inset-0 bg-gradient-to-l from-[#120A06]/95 via-[#120A06]/55 to-transparent" />
      <div className="absolute inset-0 bg-gradient-to-t from-[#120A06]/85 via-transparent to-[#120A06]/35" />

      {/* Top minimal audio & armory utility strip */}
      <div className="relative z-10 flex items-center justify-between px-6 sm:px-10 pt-5">
        <div className="flex items-center gap-3 text-sm text-[#D4BE9E]">
          <span className="font-mono-nums font-bold text-[#FBBF24]">
            ${bounty.toLocaleString()}
          </span>
          <span aria-hidden="true">·</span>
          <span className="flex items-center gap-1 font-mono-nums font-bold text-[#FCA5A5]">
            <Heart className="w-3.5 h-3.5 fill-[#EF4444] text-[#EF4444]" />
            <span>{effective.maxHp} صحة</span>
          </span>
          <span aria-hidden="true">·</span>
          <span>رصيد المكافآت</span>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={onOpenLegends}
            className="flex items-center gap-2 px-3.5 py-2 rounded-lg bg-[#291C0B]/95 border-2 border-[#0B0705] ring-1 ring-[#FBBF24]/75 hover:bg-[#3A2810] text-sm font-bold text-[#FEF08A] shadow-[0_4px_0_#0B0705] transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <Trophy className="w-4 h-4 text-[#FBBF24]" />
            <span>
              سجل الأساطير ({legendsUnlockedCount}/{LEGEND_ACHIEVEMENTS.length})
            </span>
          </button>
          <button
            onClick={onOpenShop}
            className="flex items-center gap-2 px-3.5 py-2 rounded-lg bg-[#1E2B1C]/95 border-2 border-[#0B0705] ring-1 ring-[#34D399]/70 hover:bg-[#273A24] text-sm font-bold text-[#E6F7EB] shadow-[0_4px_0_#0B0705] transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <Store className="w-4 h-4 text-[#34D399]" />
            <span>
              {huntingBagCount > 0
                ? `متجر الصيد (${huntingBagCount})`
                : 'متجر الصيد'}
            </span>
          </button>
          <button
            onClick={onOpenArmory}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#24160F]/95 border-2 border-[#0B0705] ring-1 ring-[#D99B26] hover:bg-[#3A2315] text-sm font-bold text-[#F3E5CE] shadow-[0_4px_0_#0B0705] transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <Wrench className="w-4 h-4 text-[#D99B26]" />
            <span>تطوير الصحة والترسانة</span>
          </button>
          <button
            onClick={onToggleMute}
            aria-label={muted ? 'تشغيل الصوت' : 'كتم الصوت'}
            className="p-2.5 rounded-lg bg-[#24160F]/90 border border-[#5A3A21] hover:border-[#D99B26] text-[#F3E5CE] transition-colors cursor-pointer"
          >
            {muted ? (
              <VolumeX className="w-4 h-4 text-[#9A8165]" />
            ) : (
              <Volume2 className="w-4 h-4 text-[#D99B26]" />
            )}
          </button>
        </div>
      </div>

      {/* Main Content Anchored in Negative Space */}
      <div className="relative z-10 h-[calc(100%-64px)] flex flex-col justify-between px-6 sm:px-12 pb-6 pt-3 max-w-3xl">
        {/* Bespoke Inline SVG Title Lockup */}
        <div className="space-y-3">
          <svg
            viewBox="0 0 460 120"
            className="w-full max-w-[420px] h-auto drop-shadow-[0_6px_18px_rgba(0,0,0,0.8)]"
            aria-label="رصاص الغرب"
          >
            <defs>
              <linearGradient id="brassGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#FDE68A" />
                <stop offset="50%" stopColor="#D99B26" />
                <stop offset="100%" stopColor="#92400E" />
              </linearGradient>
            </defs>
            {/* Ornamental Frontier Rule & Star */}
            <line
              x1="40"
              y1="20"
              x2="205"
              y2="20"
              stroke="#D99B26"
              strokeWidth="1.5"
              strokeOpacity="0.7"
            />
            <polygon
              points="230,8 234,17 244,17 236,23 239,32 230,26 221,32 224,23 216,17 226,17"
              fill="#D99B26"
            />
            <line
              x1="255"
              y1="20"
              x2="420"
              y2="20"
              stroke="#D99B26"
              strokeWidth="1.5"
              strokeOpacity="0.7"
            />
            <text
              x="230"
              y="88"
              textAnchor="middle"
              fill="url(#brassGrad)"
              fontFamily="Amiri, Cairo, serif"
              fontWeight="700"
              fontSize="64"
            >
              رصاص الغرب
            </text>
            <line
              x1="80"
              y1="108"
              x2="380"
              y2="108"
              stroke="#8C3F23"
              strokeWidth="2"
              strokeOpacity="0.8"
            />
          </svg>

          <p className="text-sm sm:text-base text-[#E2CEB0] leading-relaxed max-w-xl">
            واجه عصابات الحدود بالمسدس الدوّار وبندقية وينشستر 1873 والقناص شاربس وساقية مكسيم والديناميت عبر بلدات مهجورة، وديان قاحلة، قطار الذهب السريع، ونزالات الغروب.
          </p>
        </div>

        {/* Stage Selector + Difficulty */}
        <div className="space-y-4 my-auto py-3">
          <div>
            <div className="text-xs font-bold text-[#D99B26] mb-2">
              اختر المرحلة
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {STAGES.map((stage) => {
                const active = stage.id === selectedStage;
                return (
                  <button
                    key={stage.id}
                    onClick={() => onSelectStage(stage.id)}
                    className={`text-right p-2.5 rounded-lg border transition-colors cursor-pointer ${
                      active
                        ? 'bg-[#2C1B10]/95 border-[#D99B26] text-[#F3E5CE]'
                        : 'bg-[#170D08]/80 border-[#3B2416] text-[#B89F80] hover:border-[#784A29] hover:text-[#F3E5CE]'
                    }`}
                  >
                    <div className="text-[11px] font-mono-nums text-[#D99B26]">
                      0{stage.order}
                    </div>
                    <div className="text-xs sm:text-sm font-bold truncate">
                      {stage.titleAr}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Selected Stage Detail */}
          <div className="p-3.5 rounded-lg bg-[#170E09]/85 border border-[#3B2416] space-y-1">
            <div className="flex items-center gap-2 text-xs text-[#D99B26]">
              <span>{currentStageMeta.locationAr}</span>
              <span aria-hidden="true">·</span>
              <span>{currentStageMeta.objectiveAr}</span>
            </div>
            <p className="text-xs sm:text-sm text-[#D9C4A6]">
              {currentStageMeta.descriptionAr}
            </p>
          </div>

          {/* Difficulty + Posse Toggle + Primary CTA */}
          <div className="flex flex-wrap items-center gap-3 pt-1">
            <button
              onClick={onStartGame}
              className="px-8 py-3.5 rounded-lg bg-[#D99B26] hover:bg-[#FBBF24] border-2 border-[#0B0705] text-[#140B07] font-extrabold text-base shadow-[0_5px_0_#0B0705] active:translate-y-0.5 transition-all cursor-pointer whitespace-nowrap shrink-0"
            >
              ابدأ القتال
            </button>

            <div className="flex items-center gap-1 p-1 rounded-lg bg-[#1A100B]/90 border border-[#3B2416]">
              {(
                [
                  { id: 'normal', label: 'عادي' },
                  { id: 'hard', label: 'صعب' },
                  { id: 'legend', label: 'أسطوري' },
                ] as const
              ).map((d) => (
                <button
                  key={d.id}
                  onClick={() => onSelectDifficulty(d.id)}
                  className={`px-3 py-1.5 rounded-md text-xs font-bold transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                    difficulty === d.id
                      ? 'bg-[#D99B26] text-[#140B07]'
                      : 'text-[#B89F80] hover:text-[#F3E5CE]'
                  }`}
                >
                  {d.label}
                </button>
              ))}
            </div>

            <button
              onClick={onTogglePosse}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg border text-xs font-bold transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                posseEnabled
                  ? 'bg-[#0F2942]/95 border-[#38BDF8] text-[#BAE6FD]'
                  : 'bg-[#170E09]/85 border-[#3B2416] text-[#9A8165] hover:text-[#F3E5CE]'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>
                {posseEnabled
                  ? `فريق الفرسان (${effective.posseCount}): مفعل`
                  : 'فريق الفرسان: معطل'}
              </span>
            </button>
          </div>
        </div>

        {/* Single flat control-hint line */}
        <div className="text-xs text-[#B89F80] flex flex-wrap items-center gap-2">
          <span>WASD / عصا الشاشة للمشي</span>
          <span aria-hidden="true">·</span>
          <span>1-7 / Q لتبديل الأسلحة (خرطوش، توأم، قوس، مكسيم)</span>
          <span aria-hidden="true">·</span>
          <span>H أمر الفريق</span>
          <span aria-hidden="true">·</span>
          <span>Z / يمين منظار القناص + عجلة التقريب</span>
          <span aria-hidden="true">·</span>
          <span>G ديناميت</span>
          <span aria-hidden="true">·</span>
          <span>R تلقيم</span>
          <span aria-hidden="true">·</span>
          <span>Space تدحرج</span>
          <span aria-hidden="true">·</span>
          <span>E علاج</span>
        </div>
      </div>
    </div>
  );
};
