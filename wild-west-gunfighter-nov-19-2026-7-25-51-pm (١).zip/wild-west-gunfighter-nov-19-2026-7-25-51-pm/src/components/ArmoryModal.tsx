import React, { useState } from 'react';
import {
  Shield,
  Crosshair,
  Zap,
  HeartPulse,
  Flame,
  Wrench,
  Users,
  X,
} from 'lucide-react';
import { PlayerLoadout } from '../game/types';
import {
  computeEffectiveStats,
  DYNAMITE_COST,
  MAX_DYNAMITE,
  MAX_TONICS,
  TONIC_COST,
  UPGRADE_DEFS,
  UpgradeKey,
} from '../game/upgrades';

interface ArmoryModalProps {
  bounty: number;
  loadout: PlayerLoadout;
  onUpgrade: (key: UpgradeKey, cost: number) => void;
  onBuyTonic: () => void;
  onBuyDynamite: () => void;
  onClose: () => void;
}

type ArmoryTab =
  | 'health'
  | 'posse'
  | 'revolver'
  | 'winchester'
  | 'sniper'
  | 'maxim'
  | 'shotgun'
  | 'dual_pistols'
  | 'bow'
  | 'gear';

export const ArmoryModal: React.FC<ArmoryModalProps> = ({
  bounty,
  loadout,
  onUpgrade,
  onBuyTonic,
  onBuyDynamite,
  onClose,
}) => {
  const [tab, setTab] = useState<ArmoryTab>('health');
  const effective = computeEffectiveStats(loadout);
  const filteredDefs = UPGRADE_DEFS.filter((d) => d.category === tab);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4"
      role="dialog"
      aria-modal="true"
      aria-label="الترسانة وتطوير الأسلحة والصحة"
    >
      <div className="w-full max-w-3xl bg-[#1A100B] border-2 border-[#0B0705] ring-1 ring-inset ring-[#D99B26]/30 rounded-lg shadow-[0_10px_0_#0B0705] overflow-hidden text-[#F3E5CE]">
        {/* Top bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#3A2315] bg-[#140B07]">
          <div className="flex items-center gap-3">
            <Wrench className="w-5 h-5 text-[#D99B26]" />
            <div>
              <h2 className="text-xl font-bold text-[#F3E5CE]">
                ورشة الحداد والترسانة
              </h2>
              <p className="text-xs text-[#B89F80]">
                طوّر أسلحتك واشترِ السترات الواقية والأدوات المساعدة
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="text-left">
              <div className="text-[11px] text-[#B89F80]">الرصيد المتاح</div>
              <div className="text-xl font-bold text-[#FBBF24] font-mono-nums">
                ${bounty.toLocaleString()}
              </div>
            </div>
            <button
              onClick={onClose}
              aria-label="إغلاق الورشة"
              className="p-2 rounded-lg border border-[#4A2E1B] text-[#D4BE9E] hover:text-white hover:border-[#D99B26] transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Category Tabs */}
        <div className="flex items-center gap-2 px-6 pt-4 border-b border-[#3A2315] overflow-x-auto">
          <button
            onClick={() => setTab('health')}
            className={`px-4 py-2.5 text-sm font-bold border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 ${
              tab === 'health'
                ? 'border-[#EF4444] text-[#FCA5A5]'
                : 'border-transparent text-[#A88F72] hover:text-[#F3E5CE]'
            }`}
          >
            <HeartPulse className="w-4 h-4 text-[#EF4444]" />
            <span>الصحة والدروع</span>
          </button>
          <button
            onClick={() => setTab('posse')}
            className={`px-3.5 py-2.5 text-sm font-bold border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 ${
              tab === 'posse'
                ? 'border-[#38BDF8] text-[#7DD3FC]'
                : 'border-transparent text-[#A88F72] hover:text-[#F3E5CE]'
            }`}
          >
            <Users className="w-4 h-4 text-[#38BDF8]" />
            <span>فريق الفرسان</span>
          </button>
          <button
            onClick={() => setTab('revolver')}
            className={`px-3.5 py-2.5 text-sm font-bold border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              tab === 'revolver'
                ? 'border-[#D99B26] text-[#FBBF24]'
                : 'border-transparent text-[#A88F72] hover:text-[#F3E5CE]'
            }`}
          >
            المسدس .45
          </button>
          <button
            onClick={() => setTab('winchester')}
            className={`px-3.5 py-2.5 text-sm font-bold border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              tab === 'winchester'
                ? 'border-[#D99B26] text-[#FBBF24]'
                : 'border-transparent text-[#A88F72] hover:text-[#F3E5CE]'
            }`}
          >
            وينشستر 1873
          </button>
          <button
            onClick={() => setTab('sniper')}
            className={`px-3.5 py-2.5 text-sm font-bold border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              tab === 'sniper'
                ? 'border-[#D99B26] text-[#FBBF24]'
                : 'border-transparent text-[#A88F72] hover:text-[#F3E5CE]'
            }`}
          >
            قناص شاربس
          </button>
          <button
            onClick={() => setTab('maxim')}
            className={`px-3.5 py-2.5 text-sm font-bold border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              tab === 'maxim'
                ? 'border-[#D99B26] text-[#FBBF24]'
                : 'border-transparent text-[#A88F72] hover:text-[#F3E5CE]'
            }`}
          >
            ساقية مكسيم
          </button>
          <button
            onClick={() => setTab('shotgun')}
            className={`px-3.5 py-2.5 text-sm font-bold border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              tab === 'shotgun'
                ? 'border-[#FB923C] text-[#FDBA74]'
                : 'border-transparent text-[#A88F72] hover:text-[#F3E5CE]'
            }`}
          >
            الخرطوش المزدوج
          </button>
          <button
            onClick={() => setTab('dual_pistols')}
            className={`px-3.5 py-2.5 text-sm font-bold border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              tab === 'dual_pistols'
                ? 'border-[#E2E8F0] text-white'
                : 'border-transparent text-[#A88F72] hover:text-[#F3E5CE]'
            }`}
          >
            مسدسان توأم
          </button>
          <button
            onClick={() => setTab('bow')}
            className={`px-3.5 py-2.5 text-sm font-bold border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              tab === 'bow'
                ? 'border-[#34D399] text-[#6EE7B7]'
                : 'border-transparent text-[#A88F72] hover:text-[#F3E5CE]'
            }`}
          >
            قوس الصياد
          </button>
          <button
            onClick={() => setTab('gear')}
            className={`px-3.5 py-2.5 text-sm font-bold border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              tab === 'gear'
                ? 'border-[#D99B26] text-[#FBBF24]'
                : 'border-transparent text-[#A88F72] hover:text-[#F3E5CE]'
            }`}
          >
            الديناميت والمعدات
          </button>
        </div>

        {/* Summary Stat Strip */}
        <div className="px-6 py-3 bg-[#140C08] border-b border-[#3A2315] flex flex-wrap items-center gap-3 text-xs text-[#C9B190]">
          <span className="flex items-center gap-1.5">
            <HeartPulse className="w-3.5 h-3.5 text-[#EF4444]" />
            الصحة:
            <strong className="text-[#FCA5A5] font-mono-nums">
              {effective.maxHp}
            </strong>
          </span>
          <span aria-hidden="true">·</span>
          <span className="flex items-center gap-1.5">
            <Shield className="w-3.5 h-3.5 text-[#60A5FA]" />
            الدرع:
            <strong className="text-[#F3E5CE] font-mono-nums">
              {effective.maxArmor}
            </strong>
          </span>
          <span aria-hidden="true">·</span>
          <span className="flex items-center gap-1.5">
            <Users className="w-3.5 h-3.5 text-[#38BDF8]" />
            الفريق:
            <strong className="text-[#7DD3FC] font-mono-nums">
              {effective.posseCount} فرسان
            </strong>
          </span>
          <span aria-hidden="true">·</span>
          <span className="flex items-center gap-1.5">
            <Crosshair className="w-3.5 h-3.5 text-[#D99B26]" />
            الخرطوش:
            <strong className="text-[#FDBA74] font-mono-nums">
              {effective.shotgunDamage}×{effective.shotgunPellets}
            </strong>
          </span>
          <span aria-hidden="true">·</span>
          <span>
            التوأم:
            <strong className="text-[#F8FAFC] font-mono-nums mr-1">
              {effective.dualDamage}
            </strong>
          </span>
          <span aria-hidden="true">·</span>
          <span>
            القوس:
            <strong className="text-[#6EE7B7] font-mono-nums mr-1">
              {effective.bowDamage}
            </strong>
          </span>
          <span aria-hidden="true">·</span>
          <span className="flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-[#FBBF24]" />
            السرعة:
            <strong className="text-[#F3E5CE] font-mono-nums">
              {Math.round(effective.speedMultiplier * 100)}%
            </strong>
          </span>
        </div>

        {/* Upgrade List */}
        <div className="p-6 space-y-3 max-h-[55vh] overflow-y-auto">
          {filteredDefs.map((def) => {
            const currentLvl = loadout[def.key];
            const isMax = currentLvl >= def.maxLevel;
            const nextCost = isMax ? 0 : def.costs[currentLvl];
            const canAfford = !isMax && bounty >= nextCost;

            return (
              <div
                key={def.key}
                className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-lg bg-[#24160F] border border-[#3E2617]"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-3">
                    <h3 className="text-base font-bold text-[#F3E5CE]">
                      {def.titleAr}
                    </h3>
                    <span className="text-xs text-[#D99B26] font-mono-nums">
                      {def.formatEffect(currentLvl)}
                      {!isMax && ` ← ${def.formatEffect(currentLvl + 1)}`}
                    </span>
                  </div>
                  <p className="text-xs text-[#B89F80]">{def.descAr}</p>
                  {/* 3-notch level bar */}
                  <div className="flex items-center gap-1.5 pt-1">
                    {[0, 1, 2].map((notch) => (
                      <div
                        key={notch}
                        className={`h-1.5 w-8 rounded-sm transition-colors ${
                          notch < currentLvl ? 'bg-[#D99B26]' : 'bg-[#3D281A]'
                        }`}
                      />
                    ))}
                    <span className="text-[11px] text-[#9A8165] mr-2 font-mono-nums">
                      المستوى {currentLvl}/{def.maxLevel}
                    </span>
                  </div>
                </div>

                <button
                  disabled={isMax || !canAfford}
                  onClick={() => onUpgrade(def.key, nextCost)}
                  className={`px-5 py-2.5 rounded-lg text-sm font-bold whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                    isMax
                      ? 'bg-[#2C1C12] text-[#7D664E] border border-[#3E2617] cursor-default'
                      : canAfford
                        ? 'bg-[#D99B26] text-[#140B07] hover:bg-[#FBBF24]'
                        : 'bg-[#2C1C12] text-[#8E755B] border border-[#4A2E1B] cursor-not-allowed'
                  }`}
                >
                  {isMax ? 'مكتمل' : `تطوير · $${nextCost}`}
                </button>
              </div>
            );
          })}

          {/* Consumables: Field Tonics in Health Tab & Dynamite in Gear Tab */}
          {tab === 'health' && (
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-lg bg-[#1E2016] border border-[#3A4728]">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <HeartPulse className="w-4 h-4 text-[#34D399]" />
                  <h3 className="text-base font-bold text-[#F3E5CE]">
                    ترياق الإسعاف الميداني (المفتاح E)
                  </h3>
                  <span className="text-xs text-[#34D399] font-mono-nums">
                    {loadout.tonicsCount}/{MAX_TONICS}
                  </span>
                </div>
                <p className="text-xs text-[#B89F80]">
                  يعيد +{effective.tonicHeal} نقطة صحة فوراً أثناء الاشتباكات عند الضغط على E.
                </p>
              </div>

              <button
                disabled={
                  loadout.tonicsCount >= MAX_TONICS || bounty < TONIC_COST
                }
                onClick={onBuyTonic}
                className={`px-5 py-2.5 rounded-lg text-sm font-bold whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                  loadout.tonicsCount >= MAX_TONICS
                    ? 'bg-[#23291A] text-[#7B8B66] border border-[#3A4728] cursor-default'
                    : bounty >= TONIC_COST
                      ? 'bg-[#10B981] text-[#071A12] hover:bg-[#34D399]'
                      : 'bg-[#23291A] text-[#7B8B66] border border-[#3A4728] cursor-not-allowed'
                }`}
              >
                {loadout.tonicsCount >= MAX_TONICS
                  ? 'الحقيبة ممتلئة'
                  : `شراء · $${TONIC_COST}`}
              </button>
            </div>
          )}

          {tab === 'gear' && (
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-lg bg-[#261611] border border-[#6E2C1B]">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <Flame className="w-4 h-4 text-[#F97316]" />
                  <h3 className="text-base font-bold text-[#F3E5CE]">
                    شراء إصبع ديناميت إضافي (المفتاح G)
                  </h3>
                  <span className="text-xs text-[#FB923C] font-mono-nums">
                    {loadout.dynamiteCount}/{MAX_DYNAMITE}
                  </span>
                </div>
                <p className="text-xs text-[#B89F80]">
                  ارمِ الديناميت نحو تجمعات الأعداء أو الصناديق أو خزنة القطار لتفجيرها.
                </p>
              </div>

              <button
                disabled={
                  loadout.dynamiteCount >= MAX_DYNAMITE ||
                  bounty < DYNAMITE_COST
                }
                onClick={onBuyDynamite}
                className={`px-5 py-2.5 rounded-lg text-sm font-bold whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                  loadout.dynamiteCount >= MAX_DYNAMITE
                    ? 'bg-[#2C1A14] text-[#7D664E] border border-[#5A2D1E] cursor-default'
                    : bounty >= DYNAMITE_COST
                      ? 'bg-[#EA580C] text-white hover:bg-[#F97316]'
                      : 'bg-[#2C1A14] text-[#7D664E] border border-[#5A2D1E] cursor-not-allowed'
                }`}
              >
                {loadout.dynamiteCount >= MAX_DYNAMITE
                  ? 'الحزام ممتلئ'
                  : `شراء · $${DYNAMITE_COST}`}
              </button>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-[#140B07] border-t border-[#3A2315] flex items-center justify-between">
          <span className="text-xs text-[#9A8165]">
            تُحفظ الترقيات تلقائياً طوال حملتك في الغرب الأمريكي
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-lg bg-[#3A2315] hover:bg-[#4D2E1C] text-sm font-bold text-[#F3E5CE] transition-colors cursor-pointer"
          >
            عودة
          </button>
        </div>
      </div>
    </div>
  );
};
