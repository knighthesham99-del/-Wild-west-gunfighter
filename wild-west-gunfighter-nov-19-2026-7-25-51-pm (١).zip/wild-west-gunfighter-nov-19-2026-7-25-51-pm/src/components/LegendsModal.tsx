import React from 'react';
import { Award, CheckCircle2, Clock, Crosshair, Skull, Trophy, X } from 'lucide-react';
import { LEGEND_ACHIEVEMENTS } from '../game/legends';
import { LegendsRecord } from '../game/types';

interface LegendsModalProps {
  record: LegendsRecord;
  onClose: () => void;
}

export const LegendsModal: React.FC<LegendsModalProps> = ({
  record,
  onClose,
}) => {
  const evaluated = LEGEND_ACHIEVEMENTS.map((ach) => ({
    ...ach,
    state: ach.evaluate(record),
  }));
  const unlockedCount = evaluated.filter((a) => a.state.unlocked).length;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/78 p-4"
      role="dialog"
      aria-modal="true"
      aria-label="سجل الأساطير والإنجازات"
    >
      <div className="w-full max-w-3xl bg-[#1A100B] border-2 border-[#0B0705] ring-1 ring-inset ring-[#D99B26]/35 rounded-lg shadow-[0_10px_0_#0B0705] overflow-hidden text-[#F3E5CE]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#3A2315] bg-[#140B07]">
          <div className="flex items-center gap-3">
            <Trophy className="w-5 h-5 text-[#FBBF24]" />
            <div>
              <h2 className="text-xl font-bold text-[#F3E5CE]">
                سجل الأساطير وإنجازات الحدود
              </h2>
              <p className="text-xs text-[#B89F80]">
                أرقامك القياسية وأوسمة الشرف عبر بلدات الغرب الأمريكي وسهول الصيد
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="text-left">
              <div className="text-[11px] text-[#B89F80]">الأوسمة المفتوحة</div>
              <div className="text-lg font-bold text-[#FBBF24] font-mono-nums">
                {unlockedCount} / {evaluated.length}
              </div>
            </div>
            <button
              onClick={onClose}
              aria-label="إغلاق سجل الأساطير"
              className="p-2 rounded-lg border border-[#4A2E1B] text-[#D4BE9E] hover:text-white hover:border-[#D99B26] transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Highlight Personal Records Grid */}
        <div className="px-6 py-4 bg-[#140C08] border-b border-[#3A2315] grid grid-cols-2 sm:grid-cols-3 gap-3">
          <div className="p-3 rounded-lg bg-[#1D120B] border border-[#3E2617]">
            <div className="flex items-center gap-1.5 text-[11px] text-[#B89F80]">
              <Award className="w-3.5 h-3.5 text-[#F87171]" />
              <span>أكبر صيد للحيوانات النادرة</span>
            </div>
            <div className="text-xl font-bold text-[#FCA5A5] font-mono-nums mt-1">
              {record.rareAnimalsHunted} طرائد
            </div>
          </div>

          <div className="p-3 rounded-lg bg-[#1D120B] border border-[#3E2617]">
            <div className="flex items-center gap-1.5 text-[11px] text-[#B89F80]">
              <Clock className="w-3.5 h-3.5 text-[#38BDF8]" />
              <span>أسرع نزال فردي للزعيم</span>
            </div>
            <div className="text-xl font-bold text-[#67E8F9] font-mono-nums mt-1">
              {record.fastestBossDuelSeconds !== null
                ? `${record.fastestBossDuelSeconds} ثانية`
                : '—'}
            </div>
          </div>

          <div className="p-3 rounded-lg bg-[#1D120B] border border-[#3E2617]">
            <div className="flex items-center gap-1.5 text-[11px] text-[#B89F80]">
              <Skull className="w-3.5 h-3.5 text-[#FBBF24]" />
              <span>إجمالي قتلى العصابات</span>
            </div>
            <div className="text-xl font-bold text-[#FBBF24] font-mono-nums mt-1">
              {record.totalOutlawsDefeated}
            </div>
          </div>

          <div className="p-3 rounded-lg bg-[#1D120B] border border-[#3E2617]">
            <div className="flex items-center gap-1.5 text-[11px] text-[#B89F80]">
              <Crosshair className="w-3.5 h-3.5 text-[#34D399]" />
              <span>القنص الخفي المتقن</span>
            </div>
            <div className="text-xl font-bold text-[#6EE7B7] font-mono-nums mt-1">
              {record.totalStealthSniperKills}
            </div>
          </div>

          <div className="p-3 rounded-lg bg-[#1D120B] border border-[#3E2617]">
            <div className="flex items-center gap-1.5 text-[11px] text-[#B89F80]">
              <Trophy className="w-3.5 h-3.5 text-[#FB923C]" />
              <span>أعلى تتابع إصابات</span>
            </div>
            <div className="text-xl font-bold text-[#FDBA74] font-mono-nums mt-1">
              ×{record.bestCombo}
            </div>
          </div>

          <div className="p-3 rounded-lg bg-[#1D120B] border border-[#3E2617]">
            <div className="flex items-center gap-1.5 text-[11px] text-[#B89F80]">
              <Award className="w-3.5 h-3.5 text-[#A78BFA]" />
              <span>إجمالي الصيد البري</span>
            </div>
            <div className="text-xl font-bold text-[#DDD6FE] font-mono-nums mt-1">
              {record.totalAnimalsHunted} حيوان
            </div>
          </div>
        </div>

        {/* Achievements List */}
        <div className="p-6 max-h-[50vh] overflow-y-auto space-y-3">
          {evaluated.map((ach) => (
            <div
              key={ach.id}
              className={`p-4 rounded-lg border transition-colors ${
                ach.state.unlocked
                  ? 'bg-[#261B0D] border-[#D99B26]'
                  : 'bg-[#140B07] border-[#3A2315]'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <CheckCircle2
                      className={`w-4 h-4 shrink-0 ${
                        ach.state.unlocked ? 'text-[#FBBF24]' : 'text-[#5A422E]'
                      }`}
                    />
                    <h3 className="text-sm sm:text-base font-bold text-[#F3E5CE]">
                      {ach.titleAr}
                    </h3>
                  </div>
                  <p className="text-xs text-[#B89F80]">{ach.descAr}</p>
                </div>

                <div className="text-left shrink-0">
                  <div
                    className={`text-xs font-bold ${
                      ach.state.unlocked ? 'text-[#34D399]' : 'text-[#9A8165]'
                    }`}
                  >
                    {ach.state.unlocked ? ach.badgeLabelAr : 'قيد التحدي'}
                  </div>
                  <div className="text-[11px] font-mono-nums text-[#D4BE9E] mt-0.5">
                    {ach.state.progressTextAr}
                  </div>
                </div>
              </div>

              <div className="mt-2.5 h-1.5 w-full bg-[#24160F] rounded-sm overflow-hidden">
                <div
                  className={`h-full transition-all duration-300 origin-right ${
                    ach.state.unlocked ? 'bg-[#34D399]' : 'bg-[#D99B26]'
                  }`}
                  style={{ width: `${ach.state.progressPct}%` }}
                />
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-[#140B07] border-t border-[#3A2315] flex items-center justify-between">
          <span className="text-xs text-[#9A8165]">
            تُسجّل الإنجازات والأرقام القياسية تلقائياً عند إتمام المراحل أو الصيد
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-lg bg-[#D99B26] hover:bg-[#FBBF24] text-sm font-extrabold text-[#140B07] transition-colors cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
