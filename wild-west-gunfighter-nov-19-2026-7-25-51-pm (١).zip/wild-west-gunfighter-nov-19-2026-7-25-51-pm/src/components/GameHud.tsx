import React, { useRef, useState } from 'react';
import {
  Pause,
  Volume2,
  VolumeX,
  Shield,
  HeartPulse,
  Flame,
  Footprints,
  Gamepad2,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  Crosshair,
  ChevronLeft,
  ChevronRight,
  Heart,
  ZoomIn,
  ZoomOut,
  Eye,
  Users,
} from 'lucide-react';
import { HudSnapshot, WeaponId } from '../game/types';

const HERO_PORTRAIT_URL =
  '/src/assets/images/dan_west_hero_portrait_1795042480297.jpg';

interface GameHudProps {
  hud: HudSnapshot;
  muted: boolean;
  showTouchControls: boolean;
  onToggleTouchControls: () => void;
  onToggleMute: () => void;
  onPause: () => void;
  onUseTonic: () => void;
  onThrowDynamite: () => void;
  onToggleWalk: () => void;
  onSelectWeapon: (weapon: WeaponId) => void;
  onCycleWeapon: (dir: 1 | -1) => void;
  onVirtualMove: (dx: number, dy: number) => void;
  onVirtualFire: (firing: boolean) => void;
  onReload: () => void;
  onDodge: () => void;
  onDeadeye: () => void;
  onToggleScope: () => void;
  onZoomScope: (delta: number) => void;
  onTogglePosseHold: () => void;
}

export const GameHud: React.FC<GameHudProps> = ({
  hud,
  muted,
  showTouchControls,
  onToggleTouchControls,
  onToggleMute,
  onPause,
  onUseTonic,
  onThrowDynamite,
  onToggleWalk,
  onSelectWeapon,
  onCycleWeapon,
  onVirtualMove,
  onVirtualFire,
  onReload,
  onDodge,
  onDeadeye,
  onToggleScope,
  onZoomScope,
  onTogglePosseHold,
}) => {
  const hpPct = Math.max(0, Math.min(100, (hud.hp / hud.maxHp) * 100));
  const armorPct =
    hud.maxArmor > 0
      ? Math.max(0, Math.min(100, (hud.armor / hud.maxArmor) * 100))
      : 0;

  // Virtual analog stick state
  const stickRef = useRef<HTMLDivElement | null>(null);
  const [knobOffset, setKnobOffset] = useState({ x: 0, y: 0 });
  const activePointerId = useRef<number | null>(null);

  const updateStickFromPointer = (clientX: number, clientY: number) => {
    const el = stickRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const maxRadius = rect.width * 0.36;
    const dx = clientX - cx;
    const dy = clientY - cy;
    const dist = Math.hypot(dx, dy);
    const clamped = Math.min(dist, maxRadius);
    const angle = Math.atan2(dy, dx);
    const kx = dist > 0 ? Math.cos(angle) * clamped : 0;
    const ky = dist > 0 ? Math.sin(angle) * clamped : 0;
    setKnobOffset({ x: kx, y: ky });
    onVirtualMove(kx / maxRadius, ky / maxRadius);
  };

  const resetStick = () => {
    activePointerId.current = null;
    setKnobOffset({ x: 0, y: 0 });
    onVirtualMove(0, 0);
  };

  const activeAmmo =
    hud.activeWeapon === 'revolver'
      ? hud.revolverAmmo
      : hud.activeWeapon === 'winchester'
        ? hud.winchesterAmmo
        : hud.activeWeapon === 'sniper'
          ? hud.sniperAmmo
          : hud.activeWeapon === 'maxim'
            ? hud.maximAmmo
            : hud.activeWeapon === 'shotgun'
              ? hud.shotgunAmmo
              : hud.activeWeapon === 'dual_pistols'
                ? hud.dualAmmo
                : hud.bowAmmo;
  const activeReserve =
    hud.activeWeapon === 'revolver'
      ? hud.revolverReserve
      : hud.activeWeapon === 'winchester'
        ? hud.winchesterReserve
        : hud.activeWeapon === 'sniper'
          ? hud.sniperReserve
          : hud.activeWeapon === 'maxim'
            ? hud.maximReserve
            : hud.activeWeapon === 'shotgun'
              ? hud.shotgunReserve
              : hud.activeWeapon === 'dual_pistols'
                ? hud.dualReserve
                : hud.bowReserve;
  const activeNameAr =
    hud.activeWeapon === 'revolver'
      ? 'مسدس دوّار .45'
      : hud.activeWeapon === 'winchester'
        ? 'بندقية وينشستر 1873'
        : hud.activeWeapon === 'sniper'
          ? 'قناص شاربس 1874'
          : hud.activeWeapon === 'maxim'
            ? 'ساقية مكسيم'
            : hud.activeWeapon === 'shotgun'
              ? 'بندقية الخرطوش المزدوجة'
              : hud.activeWeapon === 'dual_pistols'
                ? 'مسدسا الكولت التوأم'
                : 'قوس الصياد الصامت';

  return (
    <div className="fixed inset-0 z-20 pointer-events-none flex flex-col justify-between p-4 sm:p-5">
      {/* Top Row */}
      <div className="flex items-start justify-between gap-4">
        {/* Top-Right Status Cluster: Dan-the-Man Pixel Portrait + Chunky Beveled Bars */}
        <div className="w-72 space-y-2 bg-[#1A100B]/95 border-2 border-[#0B0705] ring-1 ring-inset ring-[#D99B26]/35 rounded-lg px-3 py-2.5 shadow-[4px_4px_0_#0B0705]">
          <div className="flex items-center gap-2.5">
            {/* Pixel Hero Portrait Box */}
            <div className="w-12 h-12 shrink-0 rounded border-2 border-[#0B0705] ring-1 ring-[#D99B26] overflow-hidden bg-[#2C1A10]">
              <img
                src={HERO_PORTRAIT_URL}
                alt="بطل الغرب"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>

            <div className="flex-1 min-w-0 space-y-1.5">
              {/* Chunky Arcade HP Bar */}
              <div>
                <div className="flex items-center justify-between text-xs mb-0.5">
                  <span className="flex items-center gap-1 font-extrabold text-[#FCA5A5]">
                    <Heart className="w-3.5 h-3.5 fill-[#EF4444] text-[#EF4444]" />
                    <span>الصحة</span>
                  </span>
                  <span className="font-mono-nums font-bold text-[#F3E5CE]">
                    {hud.hp}/{hud.maxHp}
                  </span>
                </div>
                <div className="h-3 w-full bg-[#240B0B] border border-[#0B0705] rounded-sm overflow-hidden">
                  <div
                    className="h-full bg-[#DC2626] border-t border-[#FCA5A5]/60 transition-transform duration-150 origin-right"
                    style={{ transform: `scaleX(${hpPct / 100})` }}
                  />
                </div>
              </div>

              {/* Armor Bar */}
              {hud.maxArmor > 0 && (
                <div>
                  <div className="flex items-center justify-between text-[11px] mb-0.5">
                    <span className="flex items-center gap-1 text-[#93C5FD] font-bold">
                      <Shield className="w-3 h-3" />
                      الدرع
                    </span>
                    <span className="font-mono-nums text-[#93C5FD]">
                      {hud.armor}/{hud.maxArmor}
                    </span>
                  </div>
                  <div className="h-2 w-full bg-[#0F172A] border border-[#0B0705] rounded-sm overflow-hidden">
                    <div
                      className="h-full bg-[#3B82F6] border-t border-[#BAE6FD]/60 transition-transform duration-150 origin-right"
                      style={{ transform: `scaleX(${armorPct / 100})` }}
                    />
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Deadeye Focus Meter */}
          <div className="flex items-center gap-2">
            <span className="text-[11px] text-[#D99B26] font-bold whitespace-nowrap">
              عين الصقر
            </span>
            <div className="h-2 flex-1 bg-[#2C1A10] border border-[#0B0705] rounded-sm overflow-hidden">
              <div
                className={`h-full transition-transform duration-100 origin-right ${
                  hud.deadeyeActive ? 'bg-[#FDE047]' : 'bg-[#D99B26]'
                }`}
                style={{ transform: `scaleX(${hud.deadeye / 100})` }}
              />
            </div>
            <span className="text-[11px] font-mono-nums text-[#D99B26]">
              {hud.deadeye}%
            </span>
          </div>

          {/* Quick Interactive Gadgets Row: Tonic (E), Dynamite (G), Walk Mode (C) */}
          <div className="flex items-center justify-between pt-1 border-t border-[#3A2315] text-[11px]">
            <button
              onClick={onUseTonic}
              disabled={hud.tonicsCount <= 0 || hud.hp >= hud.maxHp}
              title="استخدام ترياق العلاج (E)"
              className="pointer-events-auto flex items-center gap-1 text-[#34D399] hover:text-[#6EE7B7] disabled:opacity-40 cursor-pointer"
            >
              <HeartPulse className="w-3.5 h-3.5" />
              <span>علاج (E):</span>
              <span className="font-mono-nums font-bold">{hud.tonicsCount}</span>
            </button>

            <button
              onClick={onThrowDynamite}
              disabled={hud.dynamiteCount <= 0}
              title="رمي ديناميت (G)"
              className="pointer-events-auto flex items-center gap-1 text-[#FB923C] hover:text-[#FDBA74] disabled:opacity-40 cursor-pointer"
            >
              <Flame className="w-3.5 h-3.5" />
              <span>ديناميت (G):</span>
              <span className="font-mono-nums font-bold">
                {hud.dynamiteCount}
              </span>
            </button>

            <button
              onClick={onToggleWalk}
              title="تبديل المشي الدقيق / الركض (C)"
              className={`pointer-events-auto flex items-center gap-1 cursor-pointer ${
                hud.walkMode
                  ? 'text-[#67E8F9] font-bold'
                  : 'text-[#B89F80] hover:text-[#F3E5CE]'
              }`}
            >
              <Footprints className="w-3.5 h-3.5" />
              <span>{hud.walkMode ? 'مشي' : 'ركض'}</span>
            </button>
          </div>

          {hud.alliesTotal > 0 && (
            <div className="flex items-center justify-between pt-1 border-t border-[#3A2315] text-[11px]">
              <span className="flex items-center gap-1 text-[#7DD3FC] font-bold">
                <Users className="w-3.5 h-3.5" />
                <span>الفريق المساعد:</span>
                <span className="font-mono-nums">
                  {hud.alliesAlive}/{hud.alliesTotal}
                </span>
              </span>
              <button
                onClick={onTogglePosseHold}
                title="تبديل أمر الفريق (H)"
                className={`pointer-events-auto px-2 py-0.5 rounded border text-[11px] font-bold cursor-pointer ${
                  hud.posseHold
                    ? 'bg-[#172554] border-[#38BDF8]/50 text-[#BAE6FD]'
                    : 'bg-[#082F49] border-[#38BDF8] text-white'
                }`}
              >
                {hud.posseHold ? 'تغطية صامتة (H)' : 'هجوم حر (H)'}
              </button>
            </div>
          )}
        </div>

        {/* Top-Center Objective / Wave / Boss Bar */}
        <div className="hidden md:flex flex-col items-center gap-2 max-w-md">
          <div className="bg-[#140B07]/85 border border-[#4A2E1B] rounded-lg px-4 py-2 text-center">
            <div className="flex items-center justify-center gap-2 text-xs text-[#D99B26]">
              <span className="font-bold">{hud.stageTitleAr}</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono-nums">
                الموجة {hud.waveIndex}/{hud.totalWaves}
              </span>
              {hud.trainProgressPct !== null && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono-nums">
                    التقدم {hud.trainProgressPct}%
                  </span>
                </>
              )}
              {hud.stageId === 'sniper_hunt' && (
                <>
                  <span aria-hidden="true">·</span>
                  <span
                    className={`font-mono-nums font-bold ${
                      hud.stealthAlertCount > 0
                        ? 'text-[#FCA5A5]'
                        : 'text-[#34D399]'
                    }`}
                  >
                    {hud.stealthAlertCount > 0
                      ? `مستنفرون: ${hud.stealthAlertCount}`
                      : 'وضع التسلل آمن'}
                  </span>
                </>
              )}
              {hud.stageId === 'hunting_grounds' && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono-nums font-bold text-[#6EE7B7]">
                    طرائد: {hud.animalsAlive}
                  </span>
                </>
              )}
            </div>
            <div className="text-sm font-bold text-[#F3E5CE] mt-0.5">
              {hud.objectiveAr}
            </div>
          </div>

          {hud.bossNameAr && (
            <div className="w-80 bg-[#140B07]/90 border border-[#7F1D1D] rounded-lg px-3.5 py-2">
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="font-bold text-[#FCA5A5]">
                  {hud.bossNameAr}
                </span>
                <span className="font-mono-nums text-[#FCA5A5]">
                  {hud.bossHp}/{hud.bossMaxHp}
                </span>
              </div>
              <div className="h-2.5 w-full bg-[#2B0C0C] rounded-sm overflow-hidden">
                <div
                  className="h-full bg-[#DC2626] transition-transform duration-150 origin-right"
                  style={{
                    transform: `scaleX(${
                      hud.bossMaxHp > 0 ? hud.bossHp / hud.bossMaxHp : 0
                    })`,
                  }}
                />
              </div>
            </div>
          )}
        </div>

        {/* Top-Left Bounty & Utility Controls */}
        <div className="flex items-center gap-2">
          <div className="bg-[#140B07]/85 border border-[#4A2E1B] rounded-lg px-3.5 py-2 text-left">
            <div className="text-[11px] text-[#B89F80]">المكافأة</div>
            <div className="flex items-center gap-2">
              <span className="text-lg font-bold text-[#FBBF24] font-mono-nums">
                ${hud.bounty.toLocaleString()}
              </span>
              {hud.combo > 1 && (
                <span className="text-xs font-bold text-[#FB923C] font-mono-nums">
                  ×{hud.combo}
                </span>
              )}
            </div>
          </div>

          <button
            onClick={onToggleTouchControls}
            aria-label="إظهار أو إخفاء أزرار التحكم باللمس"
            title="أزرار المشي والتحكم على الشاشة"
            className={`pointer-events-auto p-2.5 rounded-lg border transition-colors cursor-pointer ${
              showTouchControls
                ? 'bg-[#2C1B10] border-[#D99B26] text-[#FBBF24]'
                : 'bg-[#140B07]/85 border-[#4A2E1B] hover:border-[#D99B26] text-[#D4BE9E]'
            }`}
          >
            <Gamepad2 className="w-4 h-4" />
          </button>

          <button
            onClick={onToggleMute}
            aria-label={muted ? 'تشغيل الصوت' : 'كتم الصوت'}
            className="pointer-events-auto p-2.5 rounded-lg bg-[#140B07]/85 border border-[#4A2E1B] hover:border-[#D99B26] text-[#F3E5CE] transition-colors cursor-pointer"
          >
            {muted ? (
              <VolumeX className="w-4 h-4 text-[#9A8165]" />
            ) : (
              <Volume2 className="w-4 h-4 text-[#D99B26]" />
            )}
          </button>

          <button
            onClick={onPause}
            aria-label="إيقاف مؤقت"
            className="pointer-events-auto p-2.5 rounded-lg bg-[#140B07]/85 border border-[#4A2E1B] hover:border-[#D99B26] text-[#F3E5CE] transition-colors cursor-pointer"
          >
            <Pause className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Center Stage Banner / Quick-Draw Callout */}
      <div className="flex flex-col items-center justify-center gap-2">
        {hud.quickDrawBannerAr && (
          <div
            className={`px-6 py-3 rounded-lg border text-center shadow-xl ${
              hud.quickDrawPhase === 'DRAW_NOW'
                ? 'bg-[#991B1B]/95 border-[#FBBF24] text-[#FEF08A] text-2xl font-black'
                : 'bg-[#140B07]/90 border-[#D99B26] text-[#F3E5CE] text-lg font-bold'
            }`}
          >
            {hud.quickDrawBannerAr}
          </div>
        )}

        {hud.bannerMessageAr && !hud.quickDrawBannerAr && (
          <div className="px-5 py-2 rounded-lg bg-[#140B07]/85 border border-[#5A3A21] text-[#FBBF24] text-sm font-bold">
            {hud.bannerMessageAr}
          </div>
        )}
      </div>

      {/* Bottom Row: On-Screen Walking Controls (Right) + Weapon Readout & Action Pad (Left) */}
      <div className="flex items-end justify-between gap-4">
        {/* Right-side: Weapon Cluster + Optional On-Screen Walking Joystick/Pad */}
        <div className="flex items-end gap-3">
          {showTouchControls && (
            <div className="pointer-events-auto flex items-center gap-2.5">
              {/* Drag Analog Stick */}
              <div
                ref={stickRef}
                onPointerDown={(e) => {
                  e.currentTarget.setPointerCapture(e.pointerId);
                  activePointerId.current = e.pointerId;
                  updateStickFromPointer(e.clientX, e.clientY);
                }}
                onPointerMove={(e) => {
                  if (activePointerId.current === e.pointerId) {
                    updateStickFromPointer(e.clientX, e.clientY);
                  }
                }}
                onPointerUp={(e) => {
                  if (activePointerId.current === e.pointerId) {
                    resetStick();
                  }
                }}
                onPointerCancel={resetStick}
                className="relative w-28 h-28 rounded-full bg-[#140B07]/80 border-2 border-[#5A3A21] touch-none flex items-center justify-center select-none"
                aria-label="عصا التحكم بالمشي"
              >
                <div className="w-16 h-16 rounded-full border border-[#3A2315]" />
                <div
                  className="absolute w-11 h-11 rounded-full bg-[#D99B26] border-2 border-[#FEF08A] shadow-lg"
                  style={{
                    transform: `translate(${knobOffset.x}px, ${knobOffset.y}px)`,
                  }}
                />
              </div>

              {/* Crisp 4-Way Directional Hold Buttons */}
              <div className="grid grid-cols-3 gap-1 w-28">
                <div />
                <button
                  onPointerDown={() => onVirtualMove(0, -1)}
                  onPointerUp={() => onVirtualMove(0, 0)}
                  onPointerLeave={() => onVirtualMove(0, 0)}
                  aria-label="مشي للأعلى"
                  className="h-9 rounded bg-[#1A100B]/90 border border-[#4A2E1B] active:bg-[#D99B26] active:text-[#140B07] flex items-center justify-center cursor-pointer"
                >
                  <ArrowUp className="w-4 h-4" />
                </button>
                <div />
                <button
                  onPointerDown={() => onVirtualMove(1, 0)}
                  onPointerUp={() => onVirtualMove(0, 0)}
                  onPointerLeave={() => onVirtualMove(0, 0)}
                  aria-label="مشي لليمين"
                  className="h-9 rounded bg-[#1A100B]/90 border border-[#4A2E1B] active:bg-[#D99B26] active:text-[#140B07] flex items-center justify-center cursor-pointer"
                >
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  onPointerDown={() => onVirtualMove(0, 1)}
                  onPointerUp={() => onVirtualMove(0, 0)}
                  onPointerLeave={() => onVirtualMove(0, 0)}
                  aria-label="مشي للأسفل"
                  className="h-9 rounded bg-[#1A100B]/90 border border-[#4A2E1B] active:bg-[#D99B26] active:text-[#140B07] flex items-center justify-center cursor-pointer"
                >
                  <ArrowDown className="w-4 h-4" />
                </button>
                <button
                  onPointerDown={() => onVirtualMove(-1, 0)}
                  onPointerUp={() => onVirtualMove(0, 0)}
                  onPointerLeave={() => onVirtualMove(0, 0)}
                  aria-label="مشي لليسار"
                  className="h-9 rounded bg-[#1A100B]/90 border border-[#4A2E1B] active:bg-[#D99B26] active:text-[#140B07] flex items-center justify-center cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* Active Weapon & Cylinder/Scope/Maxim SVG + Quick Cycle Buttons */}
          <div className="flex items-center gap-3 bg-[#140B07]/88 border border-[#4A2E1B] rounded-lg px-3.5 py-2.5">
            {hud.activeWeapon === 'revolver' ? (
              <svg
                viewBox="0 0 64 64"
                className="w-12 h-12 shrink-0 transition-transform duration-150"
                style={{
                  transform: `rotate(${hud.revolverCylinderAngle}rad)`,
                }}
                aria-hidden="true"
              >
                <circle
                  cx="32"
                  cy="32"
                  r="28"
                  fill="#2B2D30"
                  stroke="#D99B26"
                  strokeWidth="2.5"
                />
                <circle cx="32" cy="32" r="5" fill="#140B07" />
                {[0, 1, 2, 3, 4, 5].map((idx) => {
                  const ang = (idx * Math.PI) / 3 - Math.PI / 2;
                  const cx = 32 + Math.cos(ang) * 16;
                  const cy = 32 + Math.sin(ang) * 16;
                  const loaded = idx < hud.revolverAmmo;
                  return (
                    <circle
                      key={idx}
                      cx={cx}
                      cy={cy}
                      r="5.5"
                      fill={loaded ? '#FBBF24' : '#140B07'}
                      stroke="#784A29"
                      strokeWidth="1.5"
                    />
                  );
                })}
              </svg>
            ) : hud.activeWeapon === 'winchester' ? (
              <svg
                viewBox="0 0 80 48"
                className="w-16 h-10 shrink-0"
                aria-hidden="true"
              >
                <path
                  d="M4 28 L22 24 L42 24 L46 18 L76 18 L76 22 L48 22 L44 30 L26 32 L10 38 Z"
                  fill="#8C4A22"
                  stroke="#D99B26"
                  strokeWidth="1.5"
                />
                <rect x="44" y="16" width="32" height="4" fill="#CBD5E1" />
                <circle
                  cx="33"
                  cy="34"
                  r="5"
                  fill="none"
                  stroke="#D99B26"
                  strokeWidth="2"
                />
              </svg>
            ) : hud.activeWeapon === 'sniper' ? (
              <svg
                viewBox="0 0 88 48"
                className="w-16 h-10 shrink-0"
                aria-hidden="true"
              >
                {/* Sharps 1874 Long Sniper + Brass Scope */}
                <path
                  d="M2 30 L20 25 L42 25 L46 21 L86 21 L86 24 L48 24 L44 30 L24 31 L8 38 Z"
                  fill="#6B381B"
                  stroke="#67E8F9"
                  strokeWidth="1.3"
                />
                <rect x="44" y="19" width="42" height="3.5" fill="#E2E8F0" />
                <rect x="30" y="12" width="32" height="5" rx="1.5" fill="#D99B26" />
                <circle cx="62" cy="14.5" r="2.5" fill="#67E8F9" />
              </svg>
            ) : hud.activeWeapon === 'maxim' ? (
              <svg
                viewBox="0 0 92 52"
                className="w-16 h-11 shrink-0"
                aria-hidden="true"
              >
                {/* Maxim Gun water-cooled jacket, spade grips & brass ammo belt */}
                <rect x="8" y="18" width="12" height="14" rx="2" fill="#78350F" stroke="#D99B26" strokeWidth="1.2" />
                <rect x="20" y="16" width="22" height="16" rx="2" fill="#451A03" stroke="#D99B26" strokeWidth="1.4" />
                <rect x="42" y="15" width="32" height="13" rx="3" fill="#D99B26" stroke="#FEF08A" strokeWidth="1" />
                <rect x="74" y="19" width="14" height="5" fill="#E2E8F0" />
                <rect x="25" y="32" width="14" height="12" rx="1.5" fill="#B45309" stroke="#FBBF24" strokeWidth="1.2" />
                <line x1="28" y1="35" x2="28" y2="41" stroke="#FDE047" strokeWidth="2" />
                <line x1="32" y1="35" x2="32" y2="41" stroke="#FDE047" strokeWidth="2" />
                <line x1="36" y1="35" x2="36" y2="41" stroke="#FDE047" strokeWidth="2" />
              </svg>
            ) : hud.activeWeapon === 'shotgun' ? (
              <svg
                viewBox="0 0 88 48"
                className="w-16 h-10 shrink-0"
                aria-hidden="true"
              >
                <path
                  d="M4 31 L22 25 L42 25 L46 21 L82 21 L82 27 L46 27 L42 30 L24 31 L10 38 Z"
                  fill="#7C2D12"
                  stroke="#FB923C"
                  strokeWidth="1.4"
                />
                <rect x="44" y="19" width="38" height="3.5" fill="#CBD5E1" />
                <rect x="44" y="23.5" width="38" height="3.5" fill="#94A3B8" />
              </svg>
            ) : hud.activeWeapon === 'dual_pistols' ? (
              <svg
                viewBox="0 0 76 48"
                className="w-14 h-10 shrink-0"
                aria-hidden="true"
              >
                <rect x="8" y="12" width="38" height="7" rx="1.5" fill="#E2E8F0" stroke="#0B0705" strokeWidth="1.5" />
                <rect x="10" y="18" width="10" height="10" fill="#78350F" />
                <rect x="28" y="22" width="38" height="7" rx="1.5" fill="#CBD5E1" stroke="#0B0705" strokeWidth="1.5" />
                <rect x="30" y="28" width="10" height="10" fill="#78350F" />
              </svg>
            ) : (
              <svg
                viewBox="0 0 76 52"
                className="w-14 h-11 shrink-0"
                aria-hidden="true"
              >
                <path
                  d="M26 6 Q52 26 26 46"
                  fill="none"
                  stroke="#B45309"
                  strokeWidth="4"
                  strokeLinecap="round"
                />
                <line x1="26" y1="7" x2="26" y2="45" stroke="#E5DDD0" strokeWidth="1.5" />
                <line x1="16" y1="26" x2="64" y2="26" stroke="#34D399" strokeWidth="2.5" />
                <polygon points="64,22 72,26 64,30" fill="#E2E8F0" />
              </svg>
            )}

            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-[#F3E5CE]">
                  {activeNameAr}
                </span>
                {hud.activeReloadBuffTimer > 0 && (
                  <span className="text-[11px] font-bold text-[#FBBF24]">
                    رصاص معزّز!
                  </span>
                )}
              </div>

              <div className="flex items-baseline gap-2 mt-0.5">
                <span
                  className={`text-2xl font-bold font-mono-nums ${
                    hud.activeWeapon === 'sniper'
                      ? 'text-[#67E8F9]'
                      : 'text-[#FBBF24]'
                  }`}
                >
                  {activeAmmo}
                </span>
                <span className="text-xs text-[#9A8165] font-mono-nums">
                  / {activeReserve}
                </span>
                {hud.isReloading && (
                  <span className="text-xs font-bold text-[#FDE047] mr-2">
                    {hud.activeReloadAvailable
                      ? 'اضغط R الآن!'
                      : 'جاري التلقيم...'}
                  </span>
                )}
              </div>
            </div>

            {/* Dedicated Previous / Next Weapon Cycle Buttons */}
            <div className="pointer-events-auto flex flex-col gap-1 border-r border-[#3A2315] pr-2.5 mr-1">
              <button
                onClick={() => onCycleWeapon(-1)}
                aria-label="السلاح السابق"
                title="السلاح السابق"
                className="px-2 py-1 rounded bg-[#24160F] hover:bg-[#3A2315] border border-[#5A3A21] text-[11px] font-bold text-[#F3E5CE] flex items-center gap-1 cursor-pointer whitespace-nowrap"
              >
                <ChevronRight className="w-3.5 h-3.5 text-[#D99B26]" />
                <span>السابق</span>
              </button>
              <button
                onClick={() => onCycleWeapon(1)}
                aria-label="السلاح التالي"
                title="السلاح التالي (Q)"
                className="px-2 py-1 rounded bg-[#24160F] hover:bg-[#3A2315] border border-[#5A3A21] text-[11px] font-bold text-[#F3E5CE] flex items-center gap-1 cursor-pointer whitespace-nowrap"
              >
                <span>التالي</span>
                <ChevronLeft className="w-3.5 h-3.5 text-[#D99B26]" />
              </button>
            </div>
          </div>
        </div>

        {/* Left-side: Clickable Weapon Switcher Buttons + On-Screen Action Buttons */}
        <div className="flex flex-col items-end gap-2">
          {showTouchControls && (
            <div className="pointer-events-auto flex flex-wrap items-center justify-end gap-2">
              <button
                onClick={() => onCycleWeapon(1)}
                className="px-3 py-2.5 rounded-lg bg-[#24160F]/95 border border-[#D99B26] text-xs font-bold text-[#FBBF24] cursor-pointer"
              >
                تبديل السلاح
              </button>
              <button
                onClick={onDeadeye}
                className={`px-3 py-2.5 rounded-lg border text-xs font-bold cursor-pointer ${
                  hud.deadeyeActive
                    ? 'bg-[#D99B26] text-[#140B07] border-[#FEF08A]'
                    : 'bg-[#140B07]/90 text-[#FBBF24] border-[#5A3A21]'
                }`}
              >
                عين الصقر
              </button>
              <button
                onClick={onDodge}
                className="px-3 py-2.5 rounded-lg bg-[#140B07]/90 border border-[#5A3A21] text-xs font-bold text-[#F3E5CE] cursor-pointer"
              >
                تدحرج
              </button>
              <button
                onClick={onReload}
                className="px-3 py-2.5 rounded-lg bg-[#140B07]/90 border border-[#5A3A21] text-xs font-bold text-[#F3E5CE] cursor-pointer"
              >
                تلقيم
              </button>
              <button
                onClick={onThrowDynamite}
                disabled={hud.dynamiteCount <= 0}
                className="px-3 py-2.5 rounded-lg bg-[#9A3412]/90 border border-[#F97316] text-xs font-bold text-white disabled:opacity-40 cursor-pointer"
              >
                ديناميت ({hud.dynamiteCount})
              </button>
              <button
                onPointerDown={() => onVirtualFire(true)}
                onPointerUp={() => onVirtualFire(false)}
                onPointerLeave={() => onVirtualFire(false)}
                className="px-4 py-3 rounded-lg bg-[#DC2626] active:bg-[#EF4444] border border-[#FCA5A5] text-sm font-extrabold text-white flex items-center gap-1.5 cursor-pointer"
              >
                <Crosshair className="w-4 h-4" />
                <span>إطلاق</span>
              </button>
            </div>
          )}

          {/* Sniper Telescopic Scope Toggle & Zoom Bar (visible whenever Sharps Sniper is equipped) */}
          {hud.activeWeapon === 'sniper' && (
            <div className="pointer-events-auto flex items-center gap-1.5 bg-[#0C1921]/92 border border-[#22D3EE]/50 rounded-lg px-2.5 py-1.5 text-xs shadow-lg">
              <button
                onClick={onToggleScope}
                className={`px-2.5 py-1 rounded border font-bold transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
                  hud.scopeOpen
                    ? 'bg-[#0891B2] border-[#A5F3FC] text-white'
                    : 'bg-[#132936] border-[#22D3EE]/40 text-[#67E8F9] hover:border-[#67E8F9]'
                }`}
              >
                <Eye className="w-3.5 h-3.5" />
                <span>{hud.scopeOpen ? 'إغلاق المنظار (Z)' : 'فتح المنظار (Z / يمين)'}</span>
              </button>

              {hud.scopeOpen && (
                <>
                  <button
                    onClick={() => onZoomScope(-0.35)}
                    aria-label="تبعيد المنظار"
                    title="تبعيد المنظار (-)"
                    className="px-2 py-1 rounded bg-[#132936] hover:bg-[#1B3A4B] border border-[#22D3EE]/40 text-[#A5F3FC] flex items-center gap-1 cursor-pointer whitespace-nowrap"
                  >
                    <ZoomOut className="w-3.5 h-3.5" />
                    <span>تبعيد</span>
                  </button>
                  <span className="px-2 font-mono-nums font-bold text-[#FDE047]">
                    ×{hud.scopeZoom.toFixed(1)}
                  </span>
                  <button
                    onClick={() => onZoomScope(0.35)}
                    aria-label="تقريب المنظار"
                    title="تقريب المنظار (+)"
                    className="px-2 py-1 rounded bg-[#132936] hover:bg-[#1B3A4B] border border-[#22D3EE]/40 text-[#A5F3FC] flex items-center gap-1 cursor-pointer whitespace-nowrap"
                  >
                    <ZoomIn className="w-3.5 h-3.5" />
                    <span>تقريب</span>
                  </button>
                </>
              )}
            </div>
          )}

          {/* Dedicated Clickable 7-Weapon Switcher Buttons + Prev/Next */}
          <div className="pointer-events-auto flex flex-wrap items-center justify-end gap-1 bg-[#140B07]/90 border border-[#4A2E1B] rounded-lg p-1.5 text-[11px] max-w-[60vw]">
            <button
              onClick={() => onSelectWeapon('revolver')}
              className={`px-2 py-1.5 rounded border transition-colors cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                hud.activeWeapon === 'revolver'
                  ? 'bg-[#D99B26] border-[#FEF08A] text-[#140B07] font-bold'
                  : 'bg-[#1D110A] border-[#3A2315] text-[#D4BE9E] hover:border-[#D99B26]'
              }`}
            >
              <span>[1] دوّار</span>
              <span className="font-mono-nums opacity-85">{hud.revolverAmmo}</span>
            </button>
            <button
              onClick={() => onSelectWeapon('winchester')}
              className={`px-2 py-1.5 rounded border transition-colors cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                hud.activeWeapon === 'winchester'
                  ? 'bg-[#D99B26] border-[#FEF08A] text-[#140B07] font-bold'
                  : 'bg-[#1D110A] border-[#3A2315] text-[#D4BE9E] hover:border-[#D99B26]'
              }`}
            >
              <span>[2] وينشستر</span>
              <span className="font-mono-nums opacity-85">{hud.winchesterAmmo}</span>
            </button>
            <button
              onClick={() => onSelectWeapon('sniper')}
              className={`px-2 py-1.5 rounded border transition-colors cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                hud.activeWeapon === 'sniper'
                  ? 'bg-[#0891B2] border-[#A5F3FC] text-white font-bold'
                  : 'bg-[#1D110A] border-[#3A2315] text-[#67E8F9]/90 hover:border-[#67E8F9]'
              }`}
            >
              <span>[3] قناص</span>
              <span className="font-mono-nums opacity-85">{hud.sniperAmmo}</span>
            </button>
            <button
              onClick={() => onSelectWeapon('maxim')}
              className={`px-2 py-1.5 rounded border transition-colors cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                hud.activeWeapon === 'maxim'
                  ? 'bg-[#EA580C] border-[#FDBA74] text-white font-bold'
                  : 'bg-[#1D110A] border-[#3A2315] text-[#FBBF24]/90 hover:border-[#EA580C]'
              }`}
            >
              <span>[4] مكسيم</span>
              <span className="font-mono-nums opacity-85">{hud.maximAmmo}</span>
            </button>
            <button
              onClick={() => onSelectWeapon('shotgun')}
              className={`px-2 py-1.5 rounded border transition-colors cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                hud.activeWeapon === 'shotgun'
                  ? 'bg-[#C2410C] border-[#FDBA74] text-white font-bold'
                  : 'bg-[#1D110A] border-[#3A2315] text-[#FDBA74]/90 hover:border-[#FB923C]'
              }`}
            >
              <span>[5] خرطوش</span>
              <span className="font-mono-nums opacity-85">{hud.shotgunAmmo}</span>
            </button>
            <button
              onClick={() => onSelectWeapon('dual_pistols')}
              className={`px-2 py-1.5 rounded border transition-colors cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                hud.activeWeapon === 'dual_pistols'
                  ? 'bg-[#E2E8F0] border-white text-[#0F172A] font-bold'
                  : 'bg-[#1D110A] border-[#3A2315] text-[#E2E8F0]/90 hover:border-white'
              }`}
            >
              <span>[6] توأم</span>
              <span className="font-mono-nums opacity-85">{hud.dualAmmo}</span>
            </button>
            <button
              onClick={() => onSelectWeapon('bow')}
              className={`px-2 py-1.5 rounded border transition-colors cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                hud.activeWeapon === 'bow'
                  ? 'bg-[#059669] border-[#6EE7B7] text-white font-bold'
                  : 'bg-[#1D110A] border-[#3A2315] text-[#6EE7B7]/90 hover:border-[#34D399]'
              }`}
            >
              <span>[7] قوس</span>
              <span className="font-mono-nums opacity-85">{hud.bowAmmo}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
